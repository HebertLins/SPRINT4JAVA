package program;

public class Chatbot {

	String perguntas;
	
	Chatbot(){}
	
	Chatbot(String perguntas){}
	
}
