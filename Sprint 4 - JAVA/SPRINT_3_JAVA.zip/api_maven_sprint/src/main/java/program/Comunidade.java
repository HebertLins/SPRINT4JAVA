package program;

public class Comunidade {
	Login redeSocial;
	Cadastro nome;
	
	Comunidade(){}
	
	Comunidade(Login redeSocial, Cadastro nome){}
}
