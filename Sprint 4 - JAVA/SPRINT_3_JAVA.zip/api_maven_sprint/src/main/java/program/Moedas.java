package program;

public class Moedas {

	int moedas;
	Fases bonus;
	
	Moedas(){}
	
	Moedas(int moedas, Fases bonus){}
}
