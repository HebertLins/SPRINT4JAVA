package program;

public class Usuario {

	String idSemCadastro;
	
}
