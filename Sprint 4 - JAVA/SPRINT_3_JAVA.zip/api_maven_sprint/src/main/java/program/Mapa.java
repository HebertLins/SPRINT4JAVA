package program;

public class Mapa {

	Fases fases;
	Cadastro usuario;
	Chatbot duvidas;
	Comunidade forum;
	double nivel;
	Moedas moedas;
	
	Mapa(){}
	
	Mapa(Fases fases, Cadastro usuario, Chatbot duvidas, Comunidade forum, double nivel, Moedas moedas){}
}
