package program;

public class Corretoras {
	
	String nomeCo;
	String emailCo;
	String link;
	int idCo;
	int	numTelCo;
	
	Corretoras(){}
	
	Corretoras(String nomeCo,String emailCo,String link, int idCo, int numTelCo){}
}
