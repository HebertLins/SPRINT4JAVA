package program;

public class Login {

	String redeSocial;
	String nomeLogin;
	int senhaLog;
	
}
