package program;

public class Avatar {

	
	String idAvatar;
	String nome;
	String cor;
	
	Avatar(){}

	Avatar(String idAvatar,String nome,String cor){
		this.idAvatar = idAvatar;
		this.nome = nome;
		this.cor = cor;
	}
}
